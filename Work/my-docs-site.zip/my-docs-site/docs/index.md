# Welcome to CAPTipedia!

For full code file-documentation visit [Sofie Razou's github](https://github.com/SofieRazou/Passion-projects/tree/main/Final_internship).

## Useful setup Commands (for Windows lab computer)


* `cd Desktop\sofia_code` - Enter the file directory where the GUI code lies at 
* `..\capt\Scripts\activate.bat` - Enter the python-based virtual environment

## Project layout
    
* `gui_arch.py # The parent class script for the GUI's core functionalities `
    
* `gui-styles.qss # Style file tailored to PyQt6 packege for modern looks in the CAPT Motor's dashboard`

* `udp_dspace.py #File inside dSpace's ControlDesk environment, run under Automation for live signal streaming over UDP`

* `capt_opt.py #Thread-optimized GUI file for main plotting and receiving actions during the real-time control loop`
* `SimpleScenarioAndSensorModel3DSimuilation.slx #Simulink model that hosts the Unreal Engine car driving simulation linked to both the CAPT and Moza R5 wheels` 
### Project Timeline & Milestones
```mermaid
graph TD;
    v1.0[<a href="v1.0/">v1.0</a>] --> v1.1[<a href="v1.1/">v1.1</a>];
    v1.1 --> v1.2[<a href="v1.2/">v1.2</a>];
    v1.2 --> v1.3[<a href="v1.3/">v1.3</a>];
    
    v2.0[<a href="v2.0/">v2.0</a>] --> v2.1[<a href="v2.1/">v2.1</a>];
    v2.1 --> v2.2[<a href="v2.2/">v2.2</a>] --> v2.3[<a href="v2.3/">v2.3</a>];
```