---
title: Energy-Based Controller Documentation
description: Technical overview of port-Hamiltonian formulations, passivity-based control, and energy shaping strategies for the CAPT Motor dashboard ecosystem.
---

# Energy-Based Controller Architecture

<div class="grid cards" markdown>

-   **Passivity Guarantees**

    ---

    Ensures closed-loop stability by preserving system passivity and preventing unbonded energy generation across nonlinear operating regimes.

-   **Energy Shaping**

    ---

    Manipulates potential and kinetic energy storage functions to assign desired asymptotic stability properties to equilibrium states.

-   **Power Flow Tracking**

    ---

    Monitors instantaneous real and reactive power exchange between the Moza R5 direct-drive base and the dSpace real-time target.

</div>

---

## Theoretical Formulation

The presented energy-based control scheme revolves around the notion of an energy cycle, meaning a finite amount of time where energy is injected and then discipated by the system. 

The system dynamics is formulated as a second-order linear state-space model, as such: 
$$\dot{x} = [J(x) - R(x)] \nabla H(x) + G(x)u$$

Where:
* $x$ represents the state vector (position and momentum).
* $H(x)$ is the total stored energy function (Hamiltonian).
* $J(x)$ is the skew-symmetric interconnection matrix.
* $R(x)$ is the symmetric, positive semi-definite dissipation matrix.
* $G(x)$ is the input matrix, and $u$ is the control effort.

---

## Parameter Specification Matrix

| Control Concept | Symbol / Variable | Operational Description |
| :--- | :--- | :--- |
| **`Total Hamiltonian`** | $H(x)$ | Represents the sum of kinetic and potential energy stored within the coupled motor-plant system. |
| **`Dissipation Matrix`** | $R(x)$ | Governs the natural and injected damping rates to ensure energy decay toward equilibrium. |
| **`Control Effort`** | $u$ | Computed torque command sent to the direct-drive actuator based on energy error gradients. |

---

## System Topology & Data Flow

<div class="centered-graph" markdown>

```mermaid
graph TD;
    subgraph Target [dSPACE HIL Target]
        States[System States x, x_dot]
        Hamiltonian[Energy Gradient Evaluator \nabla H(x)]
        States --> Hamiltonian
    end

    subgraph Controller [Energy-Shaping Core]
        Shaping[IDA-PBC Control Law]
        Damping[Damping Injection R(x)]
        Hamiltonian --> Shaping
        Shaping --> Damping
    end

    subgraph Actuator [Moza R5 Base]
        Command[Torque Output u]
        Motor[Direct-Drive Actuator]
        Damping --> Command
        Command --> Motor
    end
```