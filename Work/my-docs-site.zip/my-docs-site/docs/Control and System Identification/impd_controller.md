---
title: Impedance Controller Documentation
description: Technical breakdown of impedance control architectures, force-motion regulation, and dynamic parameter tuning for the CAPT Motor dashboard.
---

# Impedance Controller Architecture

<div class="grid cards" markdown>

-   **Force-Motion Regulation**

    ---

    Manages compliant interactive behavior between the active direct-drive motor and external environmental constraints.

-   **Virtual Impedance**

    ---

    Synthesizes programmable mass, damping, and stiffness matrices to shape realistic haptic feedback responses.

-   **Real-Time Stability**

    ---

    Maintains passivity and prevents oscillation across high-frequency control loops running on the dSpace target.

</div>

---

## Theoretical Formulation

Impedance control dictates how the system reacts to external disturbances or operator inputs by enforcing a desired mechanical relationship between position error and interaction force.

The generalized second-order target impedance equation is expressed as:

$$
F_{\text{ext}} = M(\ddot{x} - \ddot{x}_d) + D(\dot{x} - \dot{x}_d) + K(x - x_d)
$$

Where:
* $M$ represents the virtual inertia matrix.
* $D$ represents the virtual damping coefficient.
* $K$ represents the virtual stiffness (spring constant).
* $x$, $\dot{x}$, $\ddot{x}$ denote the actual position, velocity, and acceleration vectors.
* $x_d$, $\dot{x}_d$, $\ddot{x}_d$ denote the reference trajectories.

Where:
* $M$ represents the virtual inertia matrix.
* $D$ represents the virtual damping coefficient.
* $K$ represents the virtual stiffness (spring constant).
* $x$, $\dot{x}$, $\ddot{x}$ denote the actual position, velocity, and acceleration vectors.
* $x_d$, $\dot{x}_d$, $\ddot{x}_d$ denote the reference trajectories.

---

## Parameter Specification Matrix

| Control Parameter | Symbol / Variable | Operational Description |
| :--- | :--- | :--- |
| **`Virtual Stiffness`** | $K$ | Determines the restorative force proportional to positional displacement (e.g., configured via `Nm/rad` spinboxes). |
| **`Virtual Damping`** | $D$ | Suppresses high-frequency velocity chatter and stabilizes transitions during rapid steering adjustments. |
| **`Virtual Inertia`** | $M$ | Emulates the rotational mass and momentum of the physical steering column. |

---

## System Topology & Data Flow

<div class="centered-graph" markdown>

```mermaid
graph TD;
    subgraph Target [dSPACE HIL Target]
        Sensor[Position & Velocity Sensors]
        Impedance[Impedance Control Law]
        Sensor --> Impedance
    end

    subgraph Actuator [Moza R5 Base]
        TorqueCalc[Target Torque Generator]
        Motor[Direct-Drive Motor Base]
        Impedance -->|Calculated Torque| TorqueCalc
        TorqueCalc -->|PWM / Current Command| Motor
    end
``` 