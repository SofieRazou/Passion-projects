# Python GUI Layout and Functionality

The Motor's GUI provides live, interactive monitoring of critical system metrics, including the angle and torque values for each motor, alongside the two current phases of the **CAPT Motor**.

## Tab Functionalities

### 1. Live Signals Tab
*   **Real-time Plotting:** Visualizes active signal data as they are recorded.
*   **Data Export:** Includes an option to save captured data as a `.csv` file.
*   **Control:** Provides a "Clear Plots" function to reset tracking for a new measurement run.

### 2. Home Tab
*   **System Status:** Displays UDP server ports and IP addresses for data fetching and transmission.
*   **Hardware Integration:** Monitors status for the Moza R5.
*   **Telemetry:** Plots active telemetry signals for the CAPT Motor.
*   **Navigation:** Acts as the central core menu for all GUI functionalities.

### 3. Moza R5 Specs
*   Displays the system-ID fitted transfer function for the steering wheel, derived from empirical measurements.

### 4. Stability Analysis
*   Monitors and ensures operational stability based on approximated system models.

### 5. Transparency Analysis
*   Evaluates vital haptic benchmarks for both motors, including:
    *   **Backdrivability**
    *   **Transparency**
    *   **Haptic fidelity**

### 6. CAPT Motor Characterization
*   Performs system identification (system ID) routines specifically for the CAPT Motor.

### 7. Virtual Spring Visualization
*   Offers supplementary visual support representing the physical spring sensation transmitted to the operator by the CAPT Motor steering mechanism.