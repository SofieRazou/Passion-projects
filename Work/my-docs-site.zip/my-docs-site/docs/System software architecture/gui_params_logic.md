# CAPT Motor Dashboard Configuration

> **Stack:** PyQt6 | Python 3.9.5 | **Status:** <span class="status-active">Active</span>

---

## Overview
The following presents the architecture of the CAPT Motor GUI, that is based on the principles of modularity and optimality as far as execution goes, considering the integration of many heterogenous execution schemes, namely MATLAB, python, embedded dSpace.

---

## Configuration Reference

| Parameter | Default Value | Description |
| :--- | :--- | :--- |
| `UDP_IP` / `UDP_PORT` | `127.0.0.1:50000` | Inbound socket binding for dSPACE telemetry packets. |
| `ANGLE_FORWARD_IP` / `PORT` | `127.0.0.1:5006` | Target endpoint for forwarding processed steering angles. |
| `PLOT_WINDOW_SECONDS` | `10.0` | Visible time window length on rolling signal plots. |
| `GUI_UPDATE_PERIOD_MS` | `20` | Master UI timer interval (locks update loop strictly to 50 Hz). |
| `MOZA_R5_MAX_TORQUE` | `5.5 Nm` | Maximum output torque scaling factor for the Moza R5 wheel. |

---

## System Flow

```mermaid
graph TD;
    dSPACE[dSPACE Hardware] -->|UDP Packets| Worker[UdpWorkerThread];
    Worker -->|Thread-Safe Buffer| GUI[PyQt6 Main Window];
    GUI --> Plots[SignalPlotPage];
```
## Standard Functionalities

### High-Efficiency Data Ingestion
The dashboard implements a robust, non-blocking telemetry pipeline designed to integrate disparate execution environments (MATLAB, Python, and dSPACE embedded hardware).

*   **Asynchronous Streaming:** Telemetry data—comprising angular position, torque, and commanded current—is streamed via UDP. The GUI utilizes a non-blocking socket listener to ensure that network latency does not interrupt the main application thread.
*   **Thread-Safe Concurrency:** Packet polling is abstracted into the `UdpWorkerThread` class. To prevent race conditions during UI rendering cycles, a dedicated `threading.Lock` mechanism protects the data buffer, ensuring that the `MainWindow` only ever receives atomic, validated samples from the most recent packet.

### Real-Time Visualization & Rendering Engine
The dashboard leverages the **PyQt6** framework to provide a sophisticated, event-driven user interface capable of handling multi-tab navigation and high-frequency data updates.

*   **Modular Architecture:** The `MainWindow` serves as the primary controller, orchestrating modular components. Each widget—such as the custom `SpringWidget`—is designed for specialized tasks, such as real-time mechanical stiffness visualization or transient response modeling.
*   **Sample Processing:** Before rendering, incoming telemetry is pre-processed, normalized, and sorted into time-series buffers. This ensures that the visualizations (plots and gauges) maintain consistent temporal alignment across disparate signal sources.

---

### Functional Menu & Diagnostic Suite
The dashboard is partitioned into an intuitive suite of tools designed for rapid development, testing, and motor characterization:

| Module | Description |
| :--- | :--- |
| **Live Telemetry** | High-fidelity, real-time plotting of CAPT Motor angular displacement, torque, and current outputs. |
| **Peripheral I/O** | Dedicated monitoring and normalization for the Moza R5 steering wheel inputs. |
| **System ID** | Automated derivation of transfer functions to validate motor performance and control loop efficiency. |
| **Characterization** | Advanced analysis tools, including impedance-based transparency metrics, backdrivability comparisons, and lane-deviation benchmarks in virtual road simulations. |
| **Diagnostic Hub** | Real-time monitoring of communication nodes, including IP/Port binding, local host status, and individual motor operational modes. |

---

## Core Configuration Parameters
The system is designed for ease of maintenance; key parameters are externalized at the top of the execution module for rapid tuning:

*   **`UDP_IP` / `UDP_PORT`:** Configures the primary telemetry interface binding for dSPACE hardware integration.
*   **`ANGLE_FORWARD_IP` / `PORT`:** Specifies the feedback loop endpoint for forwarding processed steering angles to the Simulink environment.
*   **`PLOT_WINDOW_SECONDS`:** Defines the duration of the rolling telemetry window (e.g., historical data depth).
*   **`GUI_UPDATE_PERIOD_MS`:** Dictates the master UI heartbeat, ensuring a deterministic 50 Hz refresh rate for all active plots.
*   **`MOZA_R5_MAX_TORQUE`:** Scales the torque output mapping for the Moza R5 interface, allowing for precise haptic calibration.

---

## High-Level System Topology

```mermaid
graph TD;
    subgraph Hardware_Layer
        dSPACE[dSPACE Telemetry]
        MOZA[Moza R5 Controller]
    end

    subgraph Processing_Layer
        Worker[UdpWorkerThread: Non-Blocking Polling]
        Lock[Threading Lock Buffer]
    end

    subgraph UI_Layer
        Main[MainWindow UI Controller]
        Plots[SignalPlotPage: Visualization]
        Spring[SpringWidget: Mechanical Model]
    end

    dSPACE -->|UDP| Worker
    Worker -->|Write Access| Lock
    Lock -->|Read Access| Main
    MOZA -->|Pygame Axis| Main
    Main --> Plots
    Main --> Spring
``` 

create sub-pages for UDP via dSpace, UDP In simulink and in python, plotting and communication with Moza R5 using Pygame and the unreal engine loop handling. 

