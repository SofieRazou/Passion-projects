---
title: Moza R5 Integration
description: Hardware specification, Pygame axis mapping, and haptic feedback integration for the Moza R5 steering wheel system in the CAPT Motor dashboard.
---

# Moza R5 Integration Hub

<div class="grid cards" markdown>

-   **Direct Drive Feedback**

    ---

    Delivers high-fidelity haptic feedback and real-time resistance torque mapped directly from virtual driving simulations.

-   **Pygame Axis Mapping**

    ---

    Polls steering angle, accelerator, and brake inputs using low-latency asynchronous event loops within PyQt6.

-   **Hardware Handshake**

    ---

    Establishes bi-directional communication between host control scripts and physical motor peripherals.

</div>

---

## Hardware & Peripheral Specifications

To ensure seamless integration between the Moza R5 base and the CAPT Motor dashboard, configure your controller parameters according to the operational profile below.

| Configuration Parameter | Target Value | Operational Description |
| :--- | :--- | :--- |
| **`DEVICE_ID`** | `Moza R5 Base` | Recognized USB HID controller interface identifier. |
| **`POLLING_RATE`** | `100 Hz` | Dedicated event loop frequency for joystick axis and button polling. |
| **`MAX_TORQUE_SCALE`** | `5.5 Nm` | Maximum force feedback scaling factor applied to the steering column. |
| **`AXIS_MAPPING`** | `Axis 0 (Steering)` | Primary analog input mapped to virtual road curvature calculations. |

---

### Useful commands for real-time Moza R5 data extraction

For the acquisition of live angle and torque (most importantly) values from the Moza R5 wheel the `pygame` package is used, taking advantage of the USB connection between the wheel and the lab computer.
Some of the most useful commands, include the following:

#### For library initialization
* `pygame.init` : Triggers packet setup
* `pygame.joystick.init()` : Initializes communication with the wheel, over USB.

#### For device detection and connection
* `pygame.joystick.get_count()` : Getter of number of available devices connected.
* `wheel = pygame.joystick.Joystick(index)` : Setup of the index-th wheel.
* `wheel.init()` : Initialization of wheel params.

#### For real-time event polling and axis reading 
* `pygame.event.pump()`: Setting up event polling from the wheel.
* `raw_axis = self.wheel.get_axis(0)` : Fetching the physical sterring position from the primary analog axis. 

#### For resource shutdown
* `pygame.quit()`: Ensures proper shutdown of the Pygame subsystem upon closing the application window. 

---
title: Moza Pit House Software Options
description: Comprehensive configuration profile and advanced parameter tuning guide for the Moza Pit House control software within the CAPT Motor dashboard ecosystem.
---

# Moza Pit House Software Options

<div class="grid cards" markdown>

-   **Base Configuration**

    ---

    Defines core operational limits including maximum steering rotation angles and overall force feedback intensity scalers.

-   **Haptic Equalization**

    ---

    Isolates and tunes frequency bands to balance high-frequency road textures against heavy low-frequency chassis loads.

-   **Mechanical Simulation**

    ---

    Applies algorithmic damping, friction, and inertia parameters to emulate real-world steering column weight and resistance.

</div>

---

## Configuration Parameter Matrix

The Moza Pit House software suite exposes a granular set of tuning parameters designed to align virtual simulation physics with physical direct-drive hardware responses.

| Parameter Category | Configuration Option | Operational Description |
| :--- | :--- | :--- |
| **Basic Limits** | **`Maximum Steering Angle`** | Sets the total physical rotation range (e.g., 540 degrees for formula profiles or 900 degrees for GT and road setups). |
| **Basic Limits** | **`Game Force Feedback Intensity`** | Global multiplier scaling the magnitude of forces transmitted from the simulation environment to the wheel base. |
| **Advanced Feel** | **`Road Sensitivity`** | Adjusts the amplification filter governing surface details, bumps, curbs, and high-frequency vibrations. |
| **Advanced Feel** | **`Natural Inertia`** | Simulates the rotational mass of a physical steering shaft to prevent overly light or twitchy center responses. |
| **Mechanicals** | **`Wheel Friction`** | Introduces a baseline mechanical drag to mimic steering box friction or power-steering resistance. |
| **Mechanicals** | **`Wheel Damping`** | Applies velocity-dependent resistance to stabilize high-speed oscillations and reduce violent wheel snap. |
| **Equalizer** | **`FFB Effect Equalizer`** | Frequency-based slider array used to boost or attenuate specific physical feedback characteristics. |

---

## Implementation Guidelines

> **Critical Warning:** Modifications to maximum torque output and inertia scaling must be tested in a controlled environment to ensure operator safety during high-speed transient maneuvers and sudden loss-of-control scenarios.

### Tuning Procedure

1. **Profile Selection:** Create a dedicated preset profile within Moza Pit House specifically calibrated for the CAPT Motor dashboard interface.
2. **Angle Synchronization:** Ensure the software rotation limit matches the active simulation target parameters to prevent mapping skew between virtual steering inputs and physical endpoints.
3. **Damping Calibration:** Incrementally adjust wheel damping and friction values to eliminate high-frequency resonance on the direct-drive motor base.