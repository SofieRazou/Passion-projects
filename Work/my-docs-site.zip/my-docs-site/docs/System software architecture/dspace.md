---
title: dSpace Platform Integration
description: Advanced hardware-in-the-loop (HIL) architecture integrating real-time dSpace simulation targets with the CAPT Motor dashboard.
---

# dSpace Platform Integration Hub

<div class="grid cards" markdown>

-   **Real-Time Plant Core**

    ---

    Executes deterministics motor control loops at  **1 kHz** via MATLAB/Simulink targets, built using the C-Code builder inherent to MATLAB. 

-   **Streaming Pipeline**

    ---

    Streams low-latency UDP telemetry packets across local subnets with zero-blocking overhead on the core PyQt6 GUI thread.

-   **HIL Synchronization**

    ---

    Directly bridges physical motor feedback loops with simulated virtual road environments.

</div>

---
## Direct Variable Access in ControlDesk Using Tool Automation

In order to gain access to variables directly through the ControlDesk tool via the Automation tab, one can follow the commands below:

* `MyPlatform = Application.ActiveExperiment.Platforms[“Platform_1”]`:  Getter method for the active platform's identifier.
* `myVar =myPlatform.ActiveVariableDescriptionVariables[“Platform://ModelRoot/Constant/Value”]` : Getter method of the path of a specific variable, via any variable tree existent in the Variable description tab of dSpace's software. 
* `print myVar.ValueConverted` : Fetcher of the float attribute of `myVar`, on which you can perform assignments too of values. 



## Network & Telemetry Specifications

To maintain microsecond-level synchronization between the embedded target and the GUI interface, configure the Simulink UDP block parameters according to the operational profile below.

For more information, visit: [dSpace variable access documentation](https://www.dspace.com/shared/support/faqpdf/faq101.pdf)